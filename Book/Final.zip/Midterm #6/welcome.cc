#include <bits/stdc++.h>

using namespace std;

int main()
{
    cout << "For case a: 3.75 " << endl;
    cout << "In Base 2: 11.11 " << endl;
    cout << "In Base 8: 3.6" << endl;
    cout << "In Base 16: 3.C" << endl;
    cout << "In NASA: 0111 1000 0000 0000 0000 0000 0000 0010" << endl;
    cout << "In scaled binary max 1 byte: 3C x 16^-1" << endl;
    cout << "Multiplied by 7: 420" << endl;
    cout << "In IEEE 754: 0100 0000 0111 0000 0000 0000 0000 0000" << endl;
    cout << endl;
    
    cout << "For case b: .7 " << endl;
    cout << "In Base 2: 0.101100110011 " << endl;
    cout << "In Base 8: 0.546314 or 0.546315 (rounded)" << endl;
    cout << "In Base 16: 0.B333333" << endl;
    cout << "In NASA: 0101 1001 1001 1001 1001 1001 0000 0000" << endl;
    cout << "In scaled binary max 2 byte: B333 x 16^-4" << endl;
    cout << "Multiplied by 7: 321125" << endl;
    cout << "In IEEE 754: 0011 1111 0011 0011 0011 0011 0011 0011" << endl;
    cout << endl;
    
    cout << "For case a: 89.9 " << endl;
    cout << "In Base 2: 1011001.1110011001100 " << endl;
    cout << "In Base 8: 131.7146314" << endl;
    cout << "In Base 16: 59.E666" << endl;
    cout << "In NASA: 0101 1001 1110 0110 0110 0110 0000 0111" << endl;
    cout << "In scaled binary max 3 byte: 59E666 x 16^-4" << endl;
    cout << "Multiplied by 7: 41241802" << endl;
    cout << "In IEEE 754: 0100 0010 1011 0011 1100 1100 1100 1101" << endl;
    cout << endl;
}