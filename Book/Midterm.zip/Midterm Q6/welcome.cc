#include <bits/stdc++.h>

using namespace std;

main()
{
    cout << "The conversion from 2.875 base 10 is: " << endl;
    cout << "Base 2:  10.111" << endl;
    cout << "Base 8:  2.7" << endl;
    cout << "Base 16: 2.E" << endl;
    cout << "NASA Float  : 0101 1100 0000 0000 0000 0000 0000 0010" << endl;
    cout << "8 nibble hex:  5    C    0    0    0    0    0    2" << endl << endl;
    
    cout << "The conversion from .1796875 base 10 is: " << endl;
    cout << "Base 2:  0.0010111" << endl;
    cout << "Base 8:  0.134" << endl;
    cout << "Base 16: 0.2E" << endl << endl;
    cout << "NASA Float  : 0101 1100 0000 0000 0000 0000 1111 1110" << endl;
    cout << "8 nibble hex:  5    C    0    0    0    0    F    E" << endl << endl;
    
    cout << "The conversion from -2.875 base 10 is: " << endl;
    cout << "Base 2:  -10.111" << endl;
    cout << "Base 8:  -2.7" << endl;
    cout << "Base 16: -2.E" << endl << endl;
    cout << "NASA Float  : 1010 0100 0000 0000 0000 0000 0000 0010" << endl;
    cout << "8 nibble hex:  A    4    0    0    0    0    0    2" << endl << endl;
    
    cout << "The conversion from -.1796875 base 10 is: " << endl;
    cout << "Base 2:  -0.0010111" << endl;
    cout << "Base 8:  -0.134" << endl;
    cout << "Base 16: -0.2E" << endl << endl;
    cout << "NASA Float  : 1010 0100 0000 0000 0000 0000 1111 1110" << endl;
    cout << "8 nibble hex:  A    4    0    0    0    0    F    E" << endl << endl;
    
    cout << "59999901 to decimal is 1.399996877" << endl;
    cout << "59999902 to decimal is 2.799999714" << endl;
    cout << "A66667FE to decimal is -.1749999821" << endl;
    
    
}