#include <bits/stdc++.h>

using namespace std;

main()
{
    signed char a = 0;
    unsigned char b = 0;
    
    signed int c = 0;
    unsigned int d = 0;
    
    float e = 0;
    
    double f = 0;

    signed short g = 0;
    unsigned short h = 0;
    
    signed long i = 0;
    unsigned long j = 0;
    
    signed long long k = 0;
    unsigned long long l = 0;
    
    long double m;
    
    cout << "The largest factorial a signed char can take is: 5!" << endl;
    cout << "The largest factorial an unsigned char can take is: 5!" << endl;
    cout << "The largest factorial a signed int can take is: 12!" << endl;
    cout << "The largest factorial an unsigned int can take is: 12!" << endl;
    cout << "The largest factorial a signed float can take is: 11!" << endl;
    cout << "The largest factorial a signed double can take is: 11!" << endl;
    cout << "The largest factorial a signed short can take is: 7!" << endl;
    cout << "The largest factorial an unsigned short can take is: 8!" << endl;
    cout << "The largest factorial a signed long can take is: 12!" << endl;
    cout << "The largest factorial an unsigned long can take is: 12!" << endl;
    cout << "The largest factorial a signed long long can take is: 20!" << endl;
    cout << "The largest factorial an unsigned long long can take is: 20!" << endl;
    cout << "The largest factorial a long double can take is: 11!" << endl;
    
}